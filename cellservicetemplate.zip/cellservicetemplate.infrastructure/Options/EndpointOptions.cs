
namespace cellservicetemplate.infrastructure.Options;

public sealed class EndpointOptions
{
    public Dictionary<string, Endpoint>? Endpoints { get; init; }

    public sealed class Endpoint
    {
        public string? Database { get; init; }
        public string? Cache { get; init; }
    }
}
