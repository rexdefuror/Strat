
using cellservicetemplate.domain;
using MassTransit;
using Microsoft.Extensions.Options;
using Microsoft.FeatureManagement;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Options;
using System.Text.Json;

namespace cellservicetemplate.infrastructure.Mqtt;

public sealed class OrderSubmitMqttBridge : BackgroundService
{
    private readonly IFeatureManagerSnapshot _features;
    private readonly IBus _bus;

    public OrderSubmitMqttBridge(IFeatureManagerSnapshot features, IBus bus)
    {
        _features = features;
        _bus = bus;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var factory = new MqttFactory();
        using var client = factory.CreateMqttClient();

        client.ApplicationMessageReceivedAsync += async e =>
        {
            if (!await _features.IsEnabledAsync("Endpoints:OrderSubmit:Mqtt"))
                return;

            var order = JsonSerializer.Deserialize<SubmitOrder>(e.ApplicationMessage.PayloadSegment);
            if (order != null)
                await _bus.Publish(order);
        };

        var options = new MqttClientOptionsBuilder()
            .WithTcpServer("localhost", 1883)
            .Build();

        await client.ConnectAsync(options, stoppingToken);
        await client.SubscribeAsync("orders/submit");

        while (!stoppingToken.IsCancellationRequested)
            await Task.Delay(10000, stoppingToken);
    }
}
