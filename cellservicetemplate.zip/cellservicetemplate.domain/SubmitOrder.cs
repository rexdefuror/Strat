
namespace cellservicetemplate.domain;

public record SubmitOrder(Guid OrderId, string Product, int Quantity);
