
using cellservicetemplate.domain;
using MassTransit;

namespace cellservicetemplate.application;

public class SubmitOrderConsumer : IConsumer<SubmitOrder>
{
    public async Task Consume(ConsumeContext<SubmitOrder> context)
    {
        // Business logic placeholder
        await Console.Out.WriteLineAsync($"Order received: {context.Message}");
    }
}
