
using cellservicetemplate.infrastructure;
using cellservicetemplate.infrastructure.Options;
using MassTransit;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.FeatureManagement;

var builder = WebApplication.CreateSlimBuilder(args);

// Configuration binding
builder.Services.Configure<EndpointOptions>(
    builder.Configuration.GetSection("Endpoints"));

// Feature flags
builder.Services.AddFeatureManagement();

// JWT Auth
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new()
        {
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidateIssuer = true,
            ValidateAudience = false,
            IssuerSigningKey = new SymmetricSecurityKey(
                Convert.FromBase64String(builder.Configuration["Jwt:Key"]!))
        };
    });

// MassTransit
builder.Services.AddMassTransit(x =>
{
    x.AddConsumers(typeof(cellservicetemplate.application.SubmitOrderConsumer).Assembly);

    var provider = builder.Configuration["Broker:Provider"] ?? "RabbitMQ";
    if (provider.Equals("Azure", StringComparison.OrdinalIgnoreCase))
    {
        x.UsingAzureServiceBus((ctx, cfg) =>
        {
            cfg.Host(builder.Configuration["Broker:Connection"]);
            cfg.ConfigureEndpoints(ctx);
        });
    }
    else
    {
        x.UsingRabbitMq((ctx, cfg) =>
        {
            cfg.Host(new Uri(builder.Configuration["Broker:Connection"]!), h => { });
            cfg.ConfigureEndpoints(ctx);
        });
    }
});

// Conditional MQTT bridge
if (builder.Configuration.GetValue<bool>("FeatureManagement:Endpoints:OrderSubmit:Mqtt"))
{
    builder.Services.AddHostedService<cellservicetemplate.infrastructure.Mqtt.OrderSubmitMqttBridge>();
}

builder.Services.AddAuthorization();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();

app.UseSwagger();
app.UseSwaggerUI();

// Feature gated REST endpoint
var orders = app.MapGroup("/api/orders");
orders.RequireAuthorization();
orders.MapPost("/", async (cellservicetemplate.domain.SubmitOrder order, IPublishEndpoint bus) =>
{
    await bus.Publish(order);
}).WithName("SubmitOrder");

app.Run();
