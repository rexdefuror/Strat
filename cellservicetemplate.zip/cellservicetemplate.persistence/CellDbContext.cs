
using cellservicetemplate.domain;
using Microsoft.EntityFrameworkCore;

namespace cellservicetemplate.persistence;

public class CellDbContext(DbContextOptions<CellDbContext> options) : DbContext(options)
{
    public DbSet<OrderEntity> Orders => Set<OrderEntity>();
}

public class OrderEntity
{
    public Guid Id { get; set; }
    public string? Product { get; set; }
    public int Quantity { get; set; }
}
